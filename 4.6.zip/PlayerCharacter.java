/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 * 
 * Player-controlled character
 **/

// Player character class
public class PlayerCharacter extends Character {

    private String playerClass; // Character class type

    // Constructor
    public PlayerCharacter(String name, int hitPoints, int armorClass, int initiative, String playerClass) {
        super(name, hitPoints, armorClass, initiative);
        this.playerClass = playerClass;
    }

    // Display player info
    @Override
    public String display() {
        return "Player: " + name +
               " | Class: " + playerClass +
               " | HP: " + hitPoints +
               " | AC: " + getArmorClass() +
               " | Init: " + initiative +
               " | Status: " + getStatusEffects();
    }
}