/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 *
 * Simulated database manager (in-memory storage)
 **/

import java.util.ArrayList;

public class DatabaseManager {

    // Simulated "Character Table"
    private ArrayList<Character> characterTable;

    // Constructor
    public DatabaseManager() {
        characterTable = new ArrayList<>();
    }

    // CREATE (Insert)
    public void saveCharacter(Character character) {
        characterTable.add(character);
    }

    // READ (Select All)
    public ArrayList<Character> getAllCharacters() {
        return characterTable;
    }

    // READ (Find by name)
    public Character findCharacter(String name) {
        for (Character c : characterTable) {
            if (c.getName().equalsIgnoreCase(name)) {
                return c;
            }
        }
        return null;
    }

    // DELETE
    public void deleteCharacter(String name) {
        characterTable.removeIf(c -> c.getName().equalsIgnoreCase(name));
    }
}