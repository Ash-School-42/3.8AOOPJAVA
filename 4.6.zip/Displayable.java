/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 * 
 * Interface for displayable objects
 **/

// Interface for display output
public interface Displayable {
    String display(); // Returns formatted character info
}