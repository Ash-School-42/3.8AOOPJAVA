/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 * 
 * Abstract base class for all characters
 **/

import java.util.ArrayList;

// Abstract character class
public abstract class Character implements Displayable {

    protected String name; // Character name
    protected int hitPoints; // HP
    protected int armorClass; // Base AC

    protected int initiative; // Turn order

    protected ArrayList<StatusEffect> statusEffects; // Active effects

    // Constructor
    public Character(String name, int hitPoints, int armorClass, int initiative) {
        this.name = name;
        this.hitPoints = hitPoints;
        this.armorClass = armorClass;
        this.initiative = initiative;
        this.statusEffects = new ArrayList<>();
    }

    // Add status effect
    public void addStatusEffect(StatusEffect effect) {
        statusEffects.add(effect);
    }

    // Clear effects each round (your current design choice)
    public void clearStatusEffects() {
        statusEffects.clear();
    }

    // Get formatted status effects
    public String getStatusEffects() {
        if (statusEffects.isEmpty()) {
            return "NA";
        }

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < statusEffects.size(); i++) {
            result.append(statusEffects.get(i).display());

            if (i < statusEffects.size() - 1) {
                result.append(", ");
            }
        }

        return result.toString();
    }

    // Modify HP (damage/heal)
    public void modifyHP(int amount) {
        hitPoints += amount;
    }

    // Get effective AC (CALCULATED from all active effects)
    public int getArmorClass() {

        int totalModifier = 0;

        for (StatusEffect effect : statusEffects) {
            totalModifier += effect.getAcModifier();
        }

        return armorClass + totalModifier;
    }

    // Get name
    public String getName() {
        return name;
    }

    // Get initiative
    public int getInitiative() {
        return initiative;
    }

    // Abstract display method
    public abstract String display();
}