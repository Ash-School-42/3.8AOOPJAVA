/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 * 
 * Monster enemy class
 **/

// Monster class
public class Monster extends Character {

    private String type; // Monster type

    // Constructor
    public Monster(String name, int hitPoints, int armorClass, int initiative, String type) {
        super(name, hitPoints, armorClass, initiative);
        this.type = type;
    }

    // Display monster info
    @Override
    public String display() {
        return "Monster: " + name +
               " | Type: " + type +
               " | HP: " + hitPoints +
               " | AC: " + getArmorClass() +
               " | Init: " + initiative +
               " | Status: " + getStatusEffects();
    }
}