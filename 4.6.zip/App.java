/**
 * Name: James Ash
 * Date: 05-02-2026
 * Assignment: Week 4 Project
 *
 * Menu-driven Table Top RPG Encounter Manager.
 * NOW includes database support via DatabaseManager.
 **/

import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Encounter encounter = new Encounter();

        // ✅ NEW: Database manager
        DatabaseManager db = new DatabaseManager();

        int round = 1;
        boolean running = true;

        System.out.println("\n=== Table Top RPG Encounter Manager ===");

        while (running) {

            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Add Character/Monster");
            System.out.println("2. Start Encounter");
            System.out.println("3. Reset Encounter");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            String input = scanner.nextLine();

            switch (input) {

                case "1":

                    System.out.print("Type (1 = Player, 2 = Monster): ");
                    int type;

                    while (true) {
                        try {
                            type = Integer.parseInt(scanner.nextLine());
                            if (type == 1 || type == 2) break;
                            System.out.print("Enter 1 or 2: ");
                        } catch (Exception e) {
                            System.out.print("Invalid input. Enter 1 or 2: ");
                        }
                    }

                    System.out.print("Name: ");
                    String name = scanner.nextLine();

                    int hp;
                    while (true) {
                        try {
                            System.out.print("HP: ");
                            hp = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid HP: ");
                        }
                    }

                    int ac;
                    while (true) {
                        try {
                            System.out.print("AC: ");
                            ac = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid AC: ");
                        }
                    }

                    int init;
                    while (true) {
                        try {
                            System.out.print("Initiative: ");
                            init = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid Initiative: ");
                        }
                    }

                    // ✅ UPDATED: Save to both Encounter AND Database
                    if (type == 1) {

                        System.out.print("Class: ");
                        String pcClass = scanner.nextLine();

                        PlayerCharacter pc = new PlayerCharacter(name, hp, ac, init, pcClass);

                        encounter.addCharacter(pc);
                        db.saveCharacter(pc); // NEW
                    }
                    else {

                        System.out.print("Monster Type: ");
                        String mType = scanner.nextLine();

                        Monster monster = new Monster(name, hp, ac, init, mType);

                        encounter.addCharacter(monster);
                        db.saveCharacter(monster); // NEW
                    }

                    System.out.println("Character added successfully.");
                    break;

                case "2":

                    if (encounter.getParticipants().isEmpty()) {
                        System.out.println("No characters added yet.");
                        break;
                    }

                    encounter.sortInitiative();

                    boolean encounterRunning = true;

                    while (encounterRunning) {

                        System.out.println("\n--- STATUS EFFECTS (AC handled via effects) ---");

                        for (Character c : encounter.getParticipants()) {

                            c.clearStatusEffects();

                            System.out.print("Apply status to " + c.getName() + "? (y/n): ");
                            String statusChoice = scanner.nextLine();

                            if (statusChoice.equalsIgnoreCase("y")) {

                                System.out.print("Status name: ");
                                String statusName = scanner.nextLine();

                                int duration;
                                while (true) {
                                    try {
                                        System.out.print("Duration: ");
                                        duration = Integer.parseInt(scanner.nextLine());
                                        break;
                                    } catch (Exception e) {
                                        System.out.print("Invalid duration: ");
                                    }
                                }

                                System.out.print("Does this affect AC? (y/n): ");
                                String affectsAC = scanner.nextLine();

                                int acMod = 0;

                                if (affectsAC.equalsIgnoreCase("y")) {

                                    while (true) {
                                        try {
                                            System.out.print("AC modifier (+/- number): ");
                                            acMod = Integer.parseInt(scanner.nextLine());
                                            break;
                                        } catch (Exception e) {
                                            System.out.print("Invalid AC modifier: ");
                                        }
                                    }
                                }

                                c.addStatusEffect(
                                    new StatusEffect(statusName, duration, acMod)
                                );
                            }

                            System.out.print("HP change for " + c.getName() + " (0 = none): ");
                            try {
                                int hpChange = Integer.parseInt(scanner.nextLine());
                                c.modifyHP(hpChange);
                            } catch (Exception e) {
                                System.out.println("No HP change applied.");
                            }
                        }

                        encounter.displayEncounter(round);

                        System.out.print("\nNext round? (y/n): ");
                        String next = scanner.nextLine();

                        if (!next.equalsIgnoreCase("y")) {
                            encounterRunning = false;
                        } else {
                            round++;
                        }
                    }

                    break;

                case "3":

                    encounter = new Encounter();
                    round = 1;
                    System.out.println("Encounter reset successfully.");
                    break;

                case "4":

                    running = false;
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1-4.");
            }
        }

        scanner.close();
    }
}