/**
 * Name: James Ash
 * Date: 04-23-2026
 * Assignment: Week 3 Project
 * 
 * Interface for displayable objects
 **/

// Interface for display output
public interface Displayable {
    String display(); // Returns formatted character info
}