/**
 * Name: James Ash
 * Date: 04-23-2026
 * Assignment: Week 3 Project
 *
 * Menu-driven Table Top RPG Encounter Manager.
 * Handles character creation, encounter control,
 * status effects, AC modifiers (via StatusEffect),
 * HP updates, and round progression.
 **/

import java.util.Scanner;

// Main application class
public class App {
    public static void main(String[] args) {

        // Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Encounter manager (stores all characters)
        Encounter encounter = new Encounter();

        // Track round number
        int round = 1;

        // Controls main menu loop
        boolean running = true;

        System.out.println("\n=== Table Top RPG Encounter Manager ===");

        // MAIN MENU LOOP
        while (running) {

            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Add Character/Monster");
            System.out.println("2. Start Encounter");
            System.out.println("3. Reset Encounter");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            String input = scanner.nextLine();

            switch (input) {

                // ADD CHARACTER / MONSTER
                case "1":

                    System.out.print("Type (1 = Player, 2 = Monster): ");
                    int type;

                    // Validate type input
                    while (true) {
                        try {
                            type = Integer.parseInt(scanner.nextLine());
                            if (type == 1 || type == 2) break;
                            System.out.print("Enter 1 or 2: ");
                        } catch (Exception e) {
                            System.out.print("Invalid input. Enter 1 or 2: ");
                        }
                    }

                    // Name
                    System.out.print("Name: ");
                    String name = scanner.nextLine();

                    // HP
                    int hp;
                    while (true) {
                        try {
                            System.out.print("HP: ");
                            hp = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid HP: ");
                        }
                    }

                    // AC (base only)
                    int ac;
                    while (true) {
                        try {
                            System.out.print("AC: ");
                            ac = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid AC: ");
                        }
                    }

                    // Initiative
                    int init;
                    while (true) {
                        try {
                            System.out.print("Initiative: ");
                            init = Integer.parseInt(scanner.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.print("Invalid Initiative: ");
                        }
                    }

                    // Create Player
                    if (type == 1) {

                        System.out.print("Class: ");
                        String pcClass = scanner.nextLine();

                        encounter.addCharacter(
                            new PlayerCharacter(name, hp, ac, init, pcClass)
                        );
                    }

                    // Create Monster
                    else {

                        System.out.print("Monster Type: ");
                        String mType = scanner.nextLine();

                        encounter.addCharacter(
                            new Monster(name, hp, ac, init, mType)
                        );
                    }

                    System.out.println("Character added successfully.");
                    break;

                // START ENCOUNTER
                case "2":

                    // Prevent empty encounter
                    if (encounter.getParticipants().isEmpty()) {
                        System.out.println("No characters added yet.");
                        break;
                    }

                    encounter.sortInitiative();

                    boolean encounterRunning = true;

                    // COMBAT LOOP
                    while (encounterRunning) {

                        System.out.println("\n--- STATUS EFFECTS (AC handled via effects) ---");

                        // Loop through all characters each round
                        for (Character c : encounter.getParticipants()) {

                            // Reset effects each round (your current design choice)
                            c.clearStatusEffects();

                            // Ask for status effect
                            System.out.print("Apply status to " + c.getName() + "? (y/n): ");
                            String statusChoice = scanner.nextLine();

                            if (statusChoice.equalsIgnoreCase("y")) {

                                // Status name
                                System.out.print("Status name: ");
                                String statusName = scanner.nextLine();

                                // Duration
                                int duration;
                                while (true) {
                                    try {
                                        System.out.print("Duration: ");
                                        duration = Integer.parseInt(scanner.nextLine());
                                        break;
                                    } catch (Exception e) {
                                        System.out.print("Invalid duration: ");
                                    }
                                }

                                // Ask about AC effect
                                System.out.print("Does this affect AC? (y/n): ");
                                String affectsAC = scanner.nextLine();

                                int acMod = 0;

                                if (affectsAC.equalsIgnoreCase("y")) {

                                    while (true) {
                                        try {
                                            System.out.print("AC modifier (+/- number): ");
                                            acMod = Integer.parseInt(scanner.nextLine());
                                            break;
                                        } catch (Exception e) {
                                            System.out.print("Invalid AC modifier: ");
                                        }
                                    }
                                }

                                // Add status effect (with optional AC modifier)
                                c.addStatusEffect(
                                    new StatusEffect(statusName, duration, acMod)
                                );
                            }

                            // HP adjustment per round
                            System.out.print("HP change for " + c.getName() + " (0 = none): ");
                            try {
                                int hpChange = Integer.parseInt(scanner.nextLine());
                                c.modifyHP(hpChange);
                            } catch (Exception e) {
                                System.out.println("No HP change applied.");
                            }
                        }

                        // Display encounter state
                        encounter.displayEncounter(round);

                        // Next round prompt
                        System.out.print("\nNext round? (y/n): ");
                        String next = scanner.nextLine();

                        if (!next.equalsIgnoreCase("y")) {
                            encounterRunning = false;
                        } else {
                            round++;
                        }
                    }

                    break;

                // RESET ENCOUNTER
                case "3":

                    encounter = new Encounter();
                    round = 1;
                    System.out.println("Encounter reset successfully.");
                    break;

                // EXIT
                case "4":

                    running = false;
                    System.out.println("Exiting program...");
                    break;

                // INVALID INPUT
                default:
                    System.out.println("Invalid option. Please choose 1-4.");
            }
        }

        // Close scanner
        scanner.close();
    }
}