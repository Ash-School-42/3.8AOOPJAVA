/**
 * Name: James Ash
 * Date: 04-23-2026
 * Assignment: Week 3 Project
 *
 * Manages encounter participants
 **/

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// Encounter manager
public class Encounter {

    private ArrayList<Character> participants; // All characters

    // Constructor
    public Encounter() {
        participants = new ArrayList<>();
    }

    // Add character
    public void addCharacter(Character character) {
        participants.add(character);
    }

    // Get participants
    public ArrayList<Character> getParticipants() {
        return participants;
    }

    // Sort by initiative
    public void sortInitiative() {
        Collections.sort(participants,
            Comparator.comparingInt(Character::getInitiative).reversed());
    }

    // Display encounter
    public void displayEncounter(int round) {

        System.out.println("\n=== Table Top RPG Encounter Manager ===");
        System.out.println("Round: " + round);
        System.out.println("-----------------------------------");

        for (Character c : participants) {
            System.out.println(c.display());
        }
    }
}