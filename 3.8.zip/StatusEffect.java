/**
 * Name: James Ash
 * Date: 04-23-2026
 * Assignment: Week 3 Project
 * 
 * Represents a status effect with optional AC modifier
 **/

// Status effect class
public class StatusEffect {

    private String name; // Effect name
    private int duration; // Remaining rounds
    private int acModifier; // AC modifier (can be 0)

    // Constructor (no AC effect)
    public StatusEffect(String name, int duration) {
        this.name = name;
        this.duration = duration;
        this.acModifier = 0;
    }

    // Constructor (with AC effect)
    public StatusEffect(String name, int duration, int acModifier) {
        this.name = name;
        this.duration = duration;
        this.acModifier = acModifier;
    }

    // Reduce duration each round
    public void tick() {
        duration--;
    }

    // Get AC modifier from this effect
    public int getAcModifier() {
        return acModifier;
    }

    // Get remaining duration
    public int getDuration() {
        return duration;
    }

    // Display effect
    public String display() {
        if (acModifier != 0) {
            return name + " (" + duration + " rounds, AC " +
                   (acModifier > 0 ? "+" : "") + acModifier + ")";
        }
        return name + " (" + duration + " rounds)";
    }
}